import requests

print("Moin.")